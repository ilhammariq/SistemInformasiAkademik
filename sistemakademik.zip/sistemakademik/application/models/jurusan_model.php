<?php

class Jurusan_model extends CI_Model{

    public function tampil_data()
    {
        return $this->db->get('tb_jurusan');
    }

    public function input_data($data,$kode_jurusan)
    {
        $cek_kodejurusan = $this->db->get_where('tb_jurusan', array('kode_jurusan' => $kode_jurusan));
        if ($cek_kodejurusan->num_rows()>0){
            $this->session->set_flashdata('pesan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Kode Jurusan Sudah Digunakan, Mohon Diperiksa Kembali!
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>');
            redirect('administrator/jurusan');
        }else{
            $this->db->insert('tb_jurusan',$data);
            $this->session->set_flashdata('pesan','<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Data Jurusan Berhasil Ditambahkan!
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>');
            redirect('administrator/jurusan');
        }
    }

    public function edit_data($where,$table)
    {
        return $this->db->get_where($table,$where);
    }

    public function update_data($where,$data,$table)
    {
        $this->db->where($where);
        $this->db->update($table,$data);

    }

    public function hapus_data($where,$table)
    {
        $this->db->where($where);
        $this->db->delete($table);

    }
}