<div class="container-fluid">
    
    <div class="alert alert-success" role="alert">
    <i class="fas fa-university"></i> Form Input Jurusan
    </div>

    <form method="post" action="<?php echo base_url('administrator/jurusan/input_aksi') ?>">
        <div class="form-group">
            <label for="">Kode Jurusan</label>
            <input type="text" name="kode_jurusan" placeholder="Masukan Kode Jurusan" class="form-control" maxlength="3">
            <?php echo form_error('kode_jurusan', '<div class="text-danger small ml-3">','</div>') ?>
        </div>

        <div class="form-group">
            <label for="">Nama Jurusan</label>
            <input type="text" name="nama_jurusan" placeholder="Masukan Nama Jurusan" class="form-control">
            <?php echo form_error('nama_jurusan', '<div class="text-danger small ml-3">','</div>') ?>
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button>
        <a class="btn btn-danger ml-3"" href="<?php echo base_url('administrator/jurusan') ?>">Batal</a>
        
        
    </form>
</div>