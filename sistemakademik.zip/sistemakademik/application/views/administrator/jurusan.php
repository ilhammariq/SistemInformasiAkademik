<div class="container-fluid">
    <div class="alert alert-success" role="alert">
    <i class="fas fa-university"></i> Jurusan
    </div>
    
    <?php echo $this->session->flashdata('pesan') ?>
    
    <?php echo anchor('administrator/jurusan/input','<button class="btn btn-sm btn-primary mb-3"><i class="fas fa-plus fa-sm"></i> Tambah Jurusan</button>')?>
    

    <table class="table table-bordered table-striped table-hover">
        <tr>
            <th>NO</th>
            <th>KODE JURUSAN</th>
            <th>NAMA JURUSAN</th>
            <th colspan="2">AKSI</th>
        </tr>
        
        <?php
        $no = 1;
        foreach ($jurusan as $jrs) : ?>
        <tr>
            <td width="20px"><?php echo $no++ ?></td>
            <td><?php echo $jrs->kode_jurusan ?></td>
            <td><?php echo $jrs->nama_jurusan ?></td>
            <td width="20px"><?php echo anchor('administrator/jurusan/update/'.$jrs->id_jurusan,'<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>')?></td>
            <td width="20px"><div class="btn btn-sm btn-danger" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-trash"></i></div>

<!-- Modal -->
<div class="modal fade " id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><br><br><br><br><br>
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">
    <i class="fas fa-university"></i> Jurusan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Apakah anda yakin menghapus jurusan <strong><?php echo $jrs->nama_jurusan ?></strong> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <?php echo anchor('administrator/jurusan/delete/'.$jrs->id_jurusan,'<button class="btn btn-danger">Hapus</button>')?>
      </div>
    </div>
  </div>
</div></td>
        </tr>
        <?php endforeach; ?>  
    </table>
</div>